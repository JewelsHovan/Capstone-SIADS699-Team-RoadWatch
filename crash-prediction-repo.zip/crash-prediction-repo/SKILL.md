---
name: crash-prediction-repo
description: Repository-specific guidelines for the Texas crash prediction ML project. Use this skill when working on dataset building, model training, data leakage detection, or any code changes in the crash prediction repository. This skill enforces minimal changes, avoids running long scripts, and prevents data leakage.
---

# Crash Prediction Repository Guidelines

## Overview

Enforce repository-specific best practices for the Texas crash prediction ML project including data leakage prevention, minimal code changes philosophy, and proper handling of long-running scripts.

## Core Principles

### 1. Never Run Long Scripts in Session

**CRITICAL:** Dataset builders and model training scripts take 5-30+ minutes and will timeout or hang the session.

**Scripts to NEVER execute:**
- `python -m data_engineering.datasets.build_crash_level_dataset`
- `python -m data_engineering.datasets.build_segment_level_dataset`
- `python -m ml_engineering.baseline_models --both`
- Any script in `data_engineering/datasets/`
- Any script in `ml_engineering/` that trains models

**Instead:** Provide the command and tell the user to run it manually:
```
"Please run this command in your terminal:
python -m data_engineering.datasets.build_crash_level_dataset

This will take approximately 10 minutes to complete."
```

**Scripts that ARE safe to run:**
- `python -m analysis.dataset_analysis --dataset crash` (< 30 seconds)
- Test imports: `python -c "from module import something"`
- Quick syntax checks

### 2. Minimal Changes Philosophy

Per project instructions in CLAUDE.md:
- **DO NOT** create summary markdown docs unless explicitly requested
- **DO NOT** add unnecessary files to the repository
- **ALWAYS** prefer editing existing files over creating new ones
- Keep changes minimal and focused

### 3. Data Leakage Detection

**Always check for data leakage** when reviewing or creating features.

Ask these questions:
1. Is this feature calculated FROM the target variable?
2. Does this feature contain information from the future?
3. Would this feature be available at prediction time in production?

**Common leakage patterns in this project:**
- **Segment-level:** Features aggregated FROM crashes (e.g., avg_temperature calculated by averaging weather FROM crashes on each segment)
- **Derived targets:** Features computed from the target (e.g., crash_rate = crash_count / 5)
- **Temporal mismatch:** Using future data (acceptable if documented, e.g., HPMS 2023 for 2016-2020 crashes)

**Recently fixed leakage (2025-11-05):**
Removed from segment-level dataset:
- crash_rate, risk_score, high_severity_rate (derived from crash_count)
- avg_temperature, avg_visibility, avg_precipitation, avg_wind_speed (aggregated FROM crashes)

## Dataset Objectives

### Crash-Level Dataset
- **Goal:** Predict individual crash severity in real-time
- **Target:** `high_severity` (binary: 1 if Severity >= 3, else 0)
- **Use Case:** Emergency response prioritization
- **Split:** Temporal (Train: 2016-2018, Val: 2019, Test: 2020)
- **Features:** Road characteristics, weather, time, location (~28 numeric features)
- **Key Principle:** Year is used for splitting ONLY, not as a model feature

### Segment-Level Dataset
- **Goal:** Identify high-risk road segments for proactive interventions
- **Target:** `crash_count` (total crashes 2016-2020 per segment)
- **Use Case:** Road safety improvements, signage, enforcement
- **Split:** Stratified random (70/15/15)
- **Features:** Road physical characteristics only (5 base + 3 interactions = 8 features)
- **Key Challenge:** 95.6% zero-inflation (most segments have no crashes)
- **Key Principle:** NO crash-derived features (no weather aggregates, no temporal patterns FROM crashes)

## Repository Structure

```
Capstone/
├── data/
│   ├── bronze/          # Raw immutable data
│   │   └── texas/
│   │       ├── crashes/  # Kaggle US Accidents (Texas subset)
│   │       ├── traffic/  # TxDOT AADT data
│   │       └── workzones/
│   ├── silver/          # Cleaned, validated data
│   │   └── texas/roadway/  # HPMS 2023
│   └── gold/            # ML-ready datasets
│       └── ml_datasets/
│           ├── crash_level/
│           │   ├── train_latest.csv
│           │   ├── val_latest.csv
│           │   ├── test_latest.csv
│           │   └── DATA_DICTIONARY.md
│           └── segment_level/
│               ├── train_latest.csv
│               ├── val_latest.csv
│               ├── test_latest.csv
│               └── DATA_DICTIONARY.md
├── data_engineering/
│   ├── datasets/        # Dataset builders (NEVER RUN - tell user)
│   ├── download/
│   ├── clean/
│   └── integrate/
├── ml_engineering/
│   ├── baseline_models.py  # (NEVER RUN - tell user)
│   ├── models/
│   └── evaluation/
├── analysis/
│   └── dataset_analysis.py  # (OK to run - fast)
└── .claude/
    ├── CLAUDE.md           # Project instructions
    └── PROJECT_GUIDELINES.md  # (Legacy - use this skill instead)
```

## Testing Before Changes

Before modifying any dataset builder or ML script:

```bash
# Test imports
python -c "from data_engineering.datasets import build_crash_level_dataset"

# Check syntax
python -m py_compile data_engineering/datasets/build_crash_level_dataset.py

# If --sample flag exists, test with small sample
python -m data_engineering.datasets.build_crash_level_dataset --sample 1000
```

## Feature Engineering Guidelines

### Keep Features Minimal
- Prefer 5-10 meaningful features over 50+ features
- Prioritize interaction terms over many individual features
- Document any temporal mismatches (e.g., HPMS 2023 for 2016-2020 crashes)

### Valid Interaction Features (Segment-Level)
Recently added (2025-11-05):
- `speed_x_aadt` = speed_limit × aadt (exposure metric)
- `fsystem_x_urban` = f_system × urban_code (road type + location)
- `lanes_x_aadt` = through_lanes × aadt (capacity/congestion)

## Current Project State (2025-11-05)

### Recent Changes
1. **Fixed segment-level data leakage**
   - Removed 9 leakage features (crash_rate, risk_score, weather aggregates)
   - Added 3 interaction features
   - Result: 5 road features + 3 interactions + 2 targets = 10 total

2. **Implemented temporal split for crash-level**
   - Train: 2016-2018, Val: 2019, Test: 2020
   - Avoids data leakage, simulates real-world deployment

3. **Baseline models established**
   - Crash-level: LogisticRegression + RandomForest
   - Segment-level: RandomForest Regressor

### Expected Performance
- **Segment-level R² dropped** from 0.97 to < 0.5 (expected - leakage removed)
- **Crash-level:** Performance may change due to temporal split

### Datasets Need Rebuilding
After the recent fixes, both datasets need to be rebuilt:
```bash
# Tell user to run these (DO NOT run them yourself):
python -m data_engineering.datasets.build_crash_level_dataset    # ~10 min
python -m data_engineering.datasets.build_segment_level_dataset  # ~5 min
python -m ml_engineering.baseline_models --both                  # ~10 min
```

## Common Tasks Reference

### When User Requests...

**"Rebuild the datasets"**
→ Provide command, tell user to run manually (takes 5-30 min)

**"Run baseline models"**
→ Provide command, tell user to run manually (takes 10+ min)

**"Analyze the dataset"**
→ OK to run: `python -m analysis.dataset_analysis --dataset crash` (< 30 sec)

**"Create a summary doc"**
→ Provide information in response, don't create a file

**"Add more features"**
→ Ask: Is this necessary? Check for leakage. Keep minimal.

**"Fix data leakage"**
→ Review features using the 3-question check above

**"Improve model performance"**
→ First check if datasets have been rebuilt with recent fixes

## Data Sources Context

### HPMS 2023 for 2016-2020 Crashes
This temporal mismatch is **acceptable** because:
- Road infrastructure changes very slowly (especially in Texas)
- Speed limits rarely change year-to-year
- Lane counts are static unless major construction
- Functional class (Interstate vs Arterial) never changes
- This is **documented** as a known limitation

### Kaggle US Accidents Dataset
- Source: Bing/MapQuest traffic APIs (crowd-sourced)
- Texas subset: 2016-2020 (371,674 crashes)
- Original Severity scale: 1-4 (1=least severe, 4=most severe)
- Our target: high_severity = 1 if Severity >= 3, else 0

## Quick Decision Tree

```
Is user asking to run a script?
├─ YES → Check if it's in data_engineering/datasets/ or ml_engineering/
│   ├─ YES → Tell user to run it manually (provide command)
│   └─ NO → Check if it's analysis.dataset_analysis
│       ├─ YES → OK to run (< 30 sec)
│       └─ NO → Use judgment, prefer telling user to run
└─ NO → Proceed normally

Is user adding/modifying features?
├─ YES → Check for data leakage (3 questions)
│   ├─ Leakage detected → Explain issue, suggest fix
│   └─ No leakage → Proceed, keep minimal
└─ NO → Proceed normally

Is user creating new files?
├─ YES → Ask: Is this necessary? Can we edit existing instead?
└─ NO → Proceed normally
```
